const songs = [
    { title: "Dziwny jest ten świat", file: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" },
    { title: "Małgośka", file: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3" },
    { title: "Kocham Cię, kochanie moje", file: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3" },
    { title: "Zawsze tam, gdzie Ty", file: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3" },
    { title: "Za zdrowie Pań!", file: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3" },
    { title: "Jolka, Jolka pamiętasz", file: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3" },
    { title: "Szczęśliwego Nowego Roku", file: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3" },
    { title: "Nie płacz Ewka", file: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3" }
];

let currentSong = null;
let scores = {
    andrzej: 0,
    bulek: 0,
    mesi: 0,
    daniel: 0
};

document.getElementById("playButton").addEventListener("click", () => {
    currentSong = songs[Math.floor(Math.random() * songs.length)];
    const audio = new Audio(currentSong.file);
    audio.play();
});

document.getElementById("checkButton").addEventListener("click", () => {
    const userAnswer = document.getElementById("answerInput").value;
    const result = document.getElementById("result");
    const player = document.getElementById("player").value;

    if (userAnswer.toLowerCase() === currentSong.title.toLowerCase()) {
        scores[player]++;
        result.textContent = `Brawo, ${player}! Poprawna odpowiedź!`;
    } else {
        result.textContent = `Niestety, to była: ${currentSong.title}`;
    }

    updateScoreboard();
});

function updateScoreboard() {
    const scoreboard = document.getElementById("scoreboard");
    scoreboard.innerHTML = `
        <li>Andrzej: ${scores.andrzej}</li>
        <li>Bulek: ${scores.bulek}</li>
        <li>Mesi: ${scores.mesi}</li>
        <li>Daniel: ${scores.daniel}</li>
    `;
}
